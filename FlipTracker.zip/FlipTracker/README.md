# FlipTracker

Your personal flipping/reseller app.

## What is inside

- `index.html` — the app screen
- `style.css` — the design
- `app.js` — all the flipping logic
- `manifest.json` — lets the app install like a PWA
- `service-worker.js` — lets the basic app work offline
- `icons/` — app icons

## Put it online with GitHub Pages

1. Make a GitHub account.
2. Create a repository named `fliptracker`.
3. Upload everything from this folder.
4. Open the repository's **Settings**.
5. Open **Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Choose `main` and `/(root)`.
8. Save.
9. GitHub will give you a website link.
10. Open that link in Chrome on your Android phone.
11. Use Chrome's menu and choose **Install app** or **Add to Home screen**.

## Important

Your FlipTracker deals are currently saved with your browser's local storage.
That means the app does not upload your flipping history to GitHub.
